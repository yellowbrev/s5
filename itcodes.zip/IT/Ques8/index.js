$("#style").click(()=> {
    $("h1").addClass("heading");
    $("h2").addClass("heading2");
    $("p").addClass("data");
    $(".main").addClass("wrapper");
    $(".outside-div").addClass("curved");
    $(".inside-div").addClass("align");
    $("#style").hide();
});