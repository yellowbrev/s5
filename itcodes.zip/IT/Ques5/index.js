let para=document.querySelector(".para");
function changeRed(){
    para.style.backgroundColor="red";
}
function changeGreen(){
    para.style.backgroundColor="green";
}
function changeBlue(){
    para.style.backgroundColor="blue";
}
function changeFont20(){
    para.style.fontSize="20px";
}
function changeFont30(){
    para.style.fontSize="30px";
}
function changeFont40(){
    para.style.fontSize="40px";
}
function changeFont1(){
    para.style.fontFamily="monospace";
}
function changeFont2(){
    para.style.fontFamily="cursive";
}
function changeFont3(){
    para.style.fontFamily="fantasy";
}

